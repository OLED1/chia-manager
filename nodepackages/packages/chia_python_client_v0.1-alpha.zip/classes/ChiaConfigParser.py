from configparser import ConfigParser
import os

class ChiaConfigParser:
    config_object = {}

    def __init__(self):
        self.config_object = ConfigParser()
        self.configdir = "{}/config/chia-client.ini".format(os.getcwd())
        self.config_object.read(self.configdir)
        self.set_connection_info()
        self.set_node_info()

    def set_connection_info(self):
        connectioninfo = self.config_object["Connection"]
        self.__sockettype = format(connectioninfo["type"])
        self.__server = format(connectioninfo["server"])
        self.__port = format(connectioninfo["port"])
        self.__socketdir = format(connectioninfo["socketdir"])

    def set_node_info(self):
        nodeinfo = self.config_object["NodeInfo"]
        self.__authhash = format(nodeinfo["authhash"])

    def get_script_info(self):
        return self.config_object["ScriptInfo"]["version"]

    def get_connection(self):
        self.__connection = "{}://{}:{}{}".format(self.__sockettype, self.__server, self.__port, self.__socketdir)
        return self.__connection

    def get_node_info(self):
        node_info_array = {}
        node_info_array["authhash"] = self.__authhash
        return node_info_array

    def updateConfig(self, section, key, value):
        self.config_object[section][key] = value;
        with open(self.configdir, "w") as conf:
            self.config_object.write(conf)

        self.config_object.read(self.configdir)
