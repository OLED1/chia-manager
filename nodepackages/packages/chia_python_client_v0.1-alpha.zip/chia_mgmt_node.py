from classes.ChiaConfigParser import ChiaConfigParser
from classes.RequestBuilder import RequestBuilder
from classes.FirstStartWizard import FirstStartWizard
from classes.CommandInterpreter import CommandInterpreter
from classes.ConsoleFileOutputWriter import ConsoleFileOutputWriter

import websocket
import os
import socket
import json
import yaml

firststart = False

try:
    import thread
except ImportError:
    import _thread as thread
    import time

def getFirstStart():
    return firststart

def on_message(ws, message):
    command = json.loads(message)

    if getFirstStart():
        if firstStartWizard.getFirststartStep() == 2:
            if firstStartWizard.step2(command):
                consoleFileOutputWriter.writeToConsoleAndFile(0, "Finished init wizard successfully.\nWaiting for authentication on backend.")
            else:
                consoleFileOutputWriter.writeToConsoleAndFile(2, "An error occured during first start init")
        elif firstStartWizard.getFirststartStep() == 3:
            if firstStartWizard.step3(command):
                consoleFileOutputWriter.writeToConsoleAndFile(0, "Finished authentication successfully")
                firststart = False
            else:
                consoleFileOutputWriter.writeToConsoleAndFile(2, "An error occured interpreting request string from api.")
    else:
        commandInterpreterReturn = commandInterpreter.interpretCommand(command)
        if commandInterpreterReturn is not None:
            ws.send(json.dumps(commandInterpreter.interpretCommand(command)))



def on_error(ws, error):
    consoleFileOutputWriter.writeToConsoleAndFile(2, error)

def on_close(self, ws, error):
    consoleFileOutputWriter.writeToConsoleAndFile(2, error)

def on_open(ws):
    if firststart:
        authhash = ""
    else:
        authhash = chiaConfigParser.get_node_info()["authhash"]

    consoleFileOutputWriter.writeToConsoleAndFile(0, "Requesting login information from api.")
    reqdata = requestBuilder.getFormatedInfo(authhash, "ownRequest", "ChiaMgmt\\Nodes\\Nodes_Api", "Nodes_Api", "loginStatus", {})
    ws.send(json.dumps(reqdata))

    def run(*args):
        while True:
            time.sleep(5)
    thread.start_new_thread(run, ())

def start_websocket_client():
    constring = chiaConfigParser.get_connection()
    #websocket.enableTrace(True)

    ws = websocket.WebSocketApp(constring,
                              on_open = on_open,
                              on_message = on_message,
                              on_error = on_error,
                              on_close = on_close)

    ws.run_forever()

def yes_no_question(question):
    yes = set(['yes','y', 'ye', ''])
    no = set(['no','n'])

    while True:
        choice = input("{} y = Yes, n = No: ".format(question)).lower()
        if choice in yes:
            return True
        elif choice in no:
            return False
        else:
           print("&quot;Please respond with 'yes' or 'no'\n&quot");

if __name__ == "__main__":
    consoleFileOutputWriter = ConsoleFileOutputWriter()
    chiaConfigParser = ChiaConfigParser()
    consoleFileOutputWriter.writeToConsoleAndFile(0, "Starting ChiaNode python script Version: {}.".format(chiaConfigParser.get_script_info()))
    consoleFileOutputWriter.writeToConsoleAndFile(0, "Starting websocket client.")
    commandInterpreter = CommandInterpreter(consoleFileOutputWriter)
    requestBuilder = RequestBuilder()


    if chiaConfigParser.get_node_info()["authhash"] == "":
        firstStartWizard = FirstStartWizard()
        firststart = True

    start_websocket_client()
