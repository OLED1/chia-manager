import logging
import os
from datetime import datetime

class ConsoleFileOutputWriter:
    def __init__(self):
        logging.basicConfig(filename='{}/../log/chia_node_client.log'.format(os.path.dirname(os.path.realpath(__file__))), encoding='utf-8', level=logging.DEBUG, format='%(asctime)s %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')

    def writeToConsoleAndFile(self, type, message):
        msgtypestring = ""
        if type == 0:
            msgtypestring = "[INFO]"
            logging.info("{} {}".format(msgtypestring, message))
        elif type == 1:
            msgtypestring = "[WARN]"
            logging.warning("{} {}".format(msgtypestring, message))
        elif type == 2:
            msgtypestring = "[CRIT]"
            logging.error("{} {}".format(msgtypestring, message))
        else:
            msgtypestring = "[UNKN]"

        print("{} {} {}".format(self.getDateString(), msgtypestring, message))

    def getDateString(self):
        now = datetime.now()
        return now.strftime("%d.%m.%Y %H:%M:%S")
