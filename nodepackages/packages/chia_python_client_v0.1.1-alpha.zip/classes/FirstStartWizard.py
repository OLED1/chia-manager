from .ChiaConfigParser import ChiaConfigParser

class FirstStartWizard:
    def __init__(self):
        print("Starting setup wizard")
        self.firststartstep = 1

    def step1(self):
        self.chiaConfigParser = ChiaConfigParser()
        coninfo = self.chiaConfigParser.get_connection()
        print("Checking params in chia-client.ini")
        print("Websocketserver: {}".format(coninfo))

        if self.yes_no_question("Is this correct?"):
           print("fine - now testing connection to server and proceed with first login")
           self.firststartstep = 2
           return True
        else:
            print("Please correct the information in your chia-client.ini")
            return False

    def step2(self, command):
        if "data" in command and "newauthhash" in command["data"]:
            print("Got authhash '{}' from API.".format(command["data"]["newauthhash"]))
            print("Writing new hash to config file.")
            self.chiaConfigParser.updateConfig("NodeInfo","authhash",command["data"]["newauthhash"])
            self.firststartstep = 3
            return True
        else:
            return False

    def step3(self, command):
        if "method" in command and command["method"] == "loginStatus" and command["status"] == 0:
            return True
        else:
            return False

    def yes_no_question(self, question):
        yes = set(['yes','y', 'ye', ''])
        no = set(['no','n'])

        while True:
            choice = input("{} y = Yes, n = No: ".format(question)).lower()
            if choice in yes:
                return True
            elif choice in no:
                return False
            else:
               print("&quot;Please respond with 'yes' or 'no'\n&quot");

    def getFirststartStep(self):
        return int(self.firststartstep)
