from .ConsoleFileOutputWriter import ConsoleFileOutputWriter
from .ChiaConfigParser import ChiaConfigParser
from io import StringIO
from io import BytesIO
from zipfile import ZipFile
from urllib.request import urlopen
from datetime import datetime
from distutils.dir_util import copy_tree

import os, requests, time, subprocess, json

class UpdateNode:
    def __init__(self):
        self.status = {}
        self.consoleFileOutputWriter = ConsoleFileOutputWriter()
        self.chiaconfigparser = ChiaConfigParser()

    def updateNode(self, link, version):
        self.setStatus(1, "Processing Update.", 0, 2)
        self.consoleFileOutputWriter.writeToConsoleAndFile(0, "Starting Update.")

        print("Update Node")
        print(link)
        print(version)

        overall = True
        if self.createBackup():
            if self.downloadZIP(link, version):
                if self.unzipUpdate(version):
                    if self.copyLogAndConfig(version):
                        self.testNewUpdate(version)
                    else:
                        overall = False
                else:
                    overall = False
            else:
                overall = False
        else:
            overall = False


        if overall:
            self.setStatus(6, "Processed Update.", 0, 0)
            self.consoleFileOutputWriter.writeToConsoleAndFile(0, "Sucessfully processed update.")
            return ""
        else:
            self.setStatus(6, "Processed Update.", 1, 1)
            self.consoleFileOutputWriter.writeToConsoleAndFile(1, "Failed processing update.")
            return ""


    def createBackup(self):
        self.setStatus(2, "Creating Backup", 2, 2)
        self.consoleFileOutputWriter.writeToConsoleAndFile(0, "Creating Backup.")

        scriptversion = self.chiaconfigparser.get_script_info()
        rootfoldername = os.path.relpath(".","..")
        now = datetime.now()
        fromdir = "{}/../../{}".format(os.path.dirname(os.path.realpath(__file__)),rootfoldername)
        todir = "{}/../../{}-{}-{}-bkp".format(os.path.dirname(os.path.realpath(__file__)), rootfoldername, scriptversion, now.strftime("%d.%m.%Y-%H:%M:%S"))
        copyied = copy_tree(fromdir, todir)

        if os.path.exists(todir):
            self.setStatus(2, "Creating Backup (Success)", 0, 2)
            self.consoleFileOutputWriter.writeToConsoleAndFile(0, "Creating Backup: Success.")
            return True
        else:
            self.setStatus(2, "Creating Backup (Failed)", 1, 1)
            self.consoleFileOutputWriter.writeToConsoleAndFile(1, "Creating Backup: Failed.")
            return False

    def downloadZIP(self, link, version):
        self.setStatus(3, "Downloading ZIP", 2, 2)
        self.consoleFileOutputWriter.writeToConsoleAndFile(0, "Downloading ZIP.")

        results = requests.get(link)
        downloadpath = "/tmp/chia_python_client_{}.zip".format(version)
        with open(downloadpath, 'wb') as f:
            f.write(results.content)

        if os.path.exists(downloadpath):
            self.setStatus(3, "Downloading ZIP (Success)", 0, 2)
            self.consoleFileOutputWriter.writeToConsoleAndFile(0, "Downloading ZIP: Success.")
            return True
        else:
            self.setStatus(3, "Downloading ZIP (Failed)", 1, 1)
            self.consoleFileOutputWriter.writeToConsoleAndFile(0, "Downloading ZIP: Failed.")
            return False

    def unzipUpdate(self, version):
        self.setStatus(4, "Unzipping Update", 2, 2)
        self.consoleFileOutputWriter.writeToConsoleAndFile(0, "Unzipping Update.")

        downloadpath = "/tmp/chia_python_client_{}.zip".format(version)
        targetpath = "{}/../../chia_python_client_{}".format(os.path.dirname(os.path.realpath(__file__)), version)

        with ZipFile(downloadpath, 'r') as zipObj:
            zipObj.extractall('{}'.format(targetpath))

        if os.path.exists(targetpath):
            self.setStatus(4, "Unzipping Update (Success)", 0, 2)
            self.consoleFileOutputWriter.writeToConsoleAndFile(0, "Unzipping Update: Success.")
            return True
        else:
            self.setStatus(4, "Unzipping Update (Failed)", 1, 1)
            self.consoleFileOutputWriter.writeToConsoleAndFile(1, "Unzipping Update: Failed.")
            return False

    def copyLogAndConfig(self, version):
        self.setStatus(5, "Copy Log and Config", 2, 2)
        self.consoleFileOutputWriter.writeToConsoleAndFile(0, "Copy Log and Config")

        scriptversion = self.chiaconfigparser.get_script_info()
        rootfoldername = os.path.relpath(".","..")
        now = datetime.now()
        fromdir = "{}/../../{}".format(os.path.dirname(os.path.realpath(__file__)),rootfoldername)
        todir = "{}/../../chia_python_client_{}".format(os.path.dirname(os.path.realpath(__file__)), version)
        logdir = "{}/log".format(fromdir)
        configdir = "{}/config".format(fromdir)

        logcopy = copy_tree("{}/log".format(fromdir), "{}/log".format(todir))
        configcopy = copy_tree("{}/config".format(fromdir), "{}/config".format(todir))

        if os.path.exists("{}/log".format(todir)) and  os.path.exists("{}/config".format(todir)):
            self.setStatus(4, "Copy Log and Config (Success)", 0, 2)
            self.consoleFileOutputWriter.writeToConsoleAndFile(0, "Copy Log and Config: Failed.")
            return True
        else:
            self.setStatus(4, "Copy Log and Config (Failed)", 1, 1)
            self.consoleFileOutputWriter.writeToConsoleAndFile(1, "Copy Log and Config: Failed.")
            return False


    def testNewUpdate(self, version):
        self.setStatus(5, "Testing Update", 2, 2)
        self.consoleFileOutputWriter.writeToConsoleAndFile(0, "Testing Update.")

        targetpath = "{}/../../chia_python_client_{}/chia_mgmt_node.py".format(os.path.dirname(os.path.realpath(__file__)), version)
        cmd = "python {} testupdate".format(targetpath)
        print(targetpath)

        if os.path.exists(targetpath):
            print("Exists")
            proc = subprocess.Popen(['python', targetpath,  'testupdate'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            callback = json.dumps(proc.communicate()[0].splitlines()[-1].decode("utf-8"))
            print(json.loads(callback)["status"])
        else:
            self.setStatus(5, "Testing Update (Failed)", 1, 1)
            self.consoleFileOutputWriter.writeToConsoleAndFile(1, "Testing Update: Failed.")


    def getStatus(self):
        return self.status

    #status = 0 (Success), 1 (Failed), 2 (Processing)
    def setStatus(self, step, message, status, overallstatus):
        self.status[step] = {
            "status" : status,
            "message" : "{} {}".format(self.getDateString(), message)
        }
        self.status["overall"] = overallstatus

    def getDateString(self):
        now = datetime.now()
        return now.strftime("%d.%m.%Y %H:%M:%S")
