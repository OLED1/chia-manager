#!/bin/#!/usr/bin/env bash
kill -9 $1
python websocket_client.py
